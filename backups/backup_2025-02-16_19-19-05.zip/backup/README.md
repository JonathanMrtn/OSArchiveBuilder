# OSArchiveBuilder
Create a script in Python which permit tobuild an compressed archive with Python tests working with GitHub Actions
